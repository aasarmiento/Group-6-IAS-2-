/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package motorph_application;

import com.sun.tools.javac.Main;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import motorph_application.ui.LoginPanel;


/**
 *
 * @author NobbyDobbyCobby
 */
public class MotorPH_Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Read CSV from inside JAR
        try (InputStream is = Main.class.getResourceAsStream("src/motorph_application/MotorPH_EmployeeLogin.csv");
             BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
            
            System.out.println("CSV Content:");
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (Exception e) {
            System.err.println("Error reading CSV: " + e.getMessage());
        }

        // Show image from inside JAR
        try {
            ImageIcon icon = new ImageIcon(Main.class.getResource("src/motorph_application/motorphimage.png"));
            JLabel label = new JLabel(icon);
            JOptionPane.showMessageDialog(null, label, "Image Loaded from JAR", JOptionPane.PLAIN_MESSAGE);
        } catch (Exception e) {
            System.err.println("Error loading image: " + e.getMessage());
        }
        
        javax.swing.SwingUtilities.invokeLater(() -> {
        new LoginPanel();});
    
        
     
}
}
